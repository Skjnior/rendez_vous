import 'package:flutter/material.dart';

class AccueilMedecin extends StatefulWidget {
  const AccueilMedecin({super.key});

  @override
  State<AccueilMedecin> createState() => _AccueilMedecinState();
}

class _AccueilMedecinState extends State<AccueilMedecin> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}